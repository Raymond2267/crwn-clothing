import React from 'react';
import { CardList } from './components/card-list/card-list.component.js';
import './App.css';

class App extends React.Component {
  //lets us pass properties to our own defined class
  constructor() {
    super();
    this.state = {
      monsters: [],
    };
  }
  // runs after render
  componentDidMount() {
    // promise?
    const promise = fetch('https://jsonplaceholder.typicode.com/users');
    promise
      .then((response) => {
        return response.json();
      })
      .then((users) => {
        this.setState({ monsters: users });
      });
  }

  render() {
    return (
      <div className='App'>
        <CardList monsters={this.state.monsters} />
      </div>
    );
  }
}

export default App;
